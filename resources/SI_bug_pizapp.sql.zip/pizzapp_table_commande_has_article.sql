
-- --------------------------------------------------------

--
-- Structure de la table `commande_has_article`
--
-- Création : mar. 17 mai 2022 à 07:06
-- Dernière modification : mar. 17 mai 2022 à 07:06
--

DROP TABLE IF EXISTS `commande_has_article`;
CREATE TABLE IF NOT EXISTS `commande_has_article` (
  `commande_id` int DEFAULT NULL,
  `pizza_id` int DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;
