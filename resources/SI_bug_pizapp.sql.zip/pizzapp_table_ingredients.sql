
-- --------------------------------------------------------

--
-- Structure de la table `ingredients`
--
-- Création : sam. 14 mai 2022 à 13:32
--

DROP TABLE IF EXISTS `ingredients`;
CREATE TABLE IF NOT EXISTS `ingredients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `label` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `nb_calories` int NOT NULL,
  `prix` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `ingredients`
--

INSERT INTO `ingredients` (`id`, `type`, `label`, `nb_calories`, `prix`) VALUES
(1, 'pate', 'pate fine', 120, 3),
(2, 'pate', 'pate épaisse', 130, 3.5),
(3, 'base', 'sauce tomate', 25, 1.33),
(4, 'base', 'sauce fromage', 230, 1.5),
(5, 'vert', 'roquette', 12, 0.5),
(6, 'vert', 'basilic', 10, 0.5),
(7, 'viande', 'poulet', 80, 2.22),
(8, 'viande', 'boeuf', 130, 1.35),
(9, 'viande', 'saucisse', 120, 1.15),
(10, 'fromage', 'mozzarella', 40, 0.3),
(11, 'fromage', 'emmental', 170, 0.3),
(12, 'fromage', 'roquefort', 164, 0.34),
(13, 'viande', 'Jambon', 140, 1.3);
