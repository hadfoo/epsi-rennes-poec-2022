
-- --------------------------------------------------------

--
-- Structure de la table `order`
--
-- Création : lun. 16 mai 2022 à 22:27
--

DROP TABLE IF EXISTS `order`;
CREATE TABLE IF NOT EXISTS `order` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mail` varchar(120) COLLATE utf8_bin NOT NULL,
  `commande_uuid` varchar(128) COLLATE utf8_bin NOT NULL,
  `TVA` double NOT NULL,
  `prix_ttc` double NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `order`
--

INSERT INTO `order` (`id`, `mail`, `commande_uuid`, `TVA`, `prix_ttc`, `date`) VALUES
(4, 'gael', '{\"pizza\": \"Margharita\",\"prix\": \"5.63\",\"pizza\": \"Margharita\",\"prix\": \"5.63\",\"pizza\": \"4Fromages\",\"prix\": \"4.94\",\"pizza\": \"Marghar', 2.1483886255924176, 41.209999999999994, '2022-05-17 14:33:38'),
(5, 'gael', '{Margharita\",Royale}', 0.7986729857819892, 15.32, '2022-05-17 14:35:31');
