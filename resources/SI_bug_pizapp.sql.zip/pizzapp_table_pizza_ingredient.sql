
-- --------------------------------------------------------

--
-- Structure de la table `pizza_ingredient`
--
-- Création : sam. 14 mai 2022 à 13:32
-- Dernière modification : mar. 17 mai 2022 à 08:01
--

DROP TABLE IF EXISTS `pizza_ingredient`;
CREATE TABLE IF NOT EXISTS `pizza_ingredient` (
  `pizza_id` int UNSIGNED NOT NULL,
  `ingredient_id` int UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `pizza_ingredient`
--

INSERT INTO `pizza_ingredient` (`pizza_id`, `ingredient_id`) VALUES
(1, 1),
(1, 3),
(1, 5),
(1, 6),
(1, 10),
(2, 1),
(2, 5),
(2, 6),
(2, 10),
(2, 11),
(2, 12),
(3, 1),
(3, 3),
(3, 9),
(3, 8),
(3, 7),
(3, 12),
(3, 10),
(4, 2),
(4, 3),
(4, 6),
(4, 7),
(4, 7),
(4, 8),
(4, 10),
(4, 11),
(4, 13);
