
-- --------------------------------------------------------

--
-- Structure de la table `panier`
--
-- Création : sam. 14 mai 2022 à 13:32
--

DROP TABLE IF EXISTS `panier`;
CREATE TABLE IF NOT EXISTS `panier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `panier`
--

INSERT INTO `panier` (`id`, `timestamp`) VALUES
(1, '2022-05-14T11:03:46.2215818'),
(2, '2022-05-15T22:33:50.9817542'),
(3, '2022-05-15T22:33:55.4647728'),
(4, '2022-05-15T22:33:56.358489'),
(5, '2022-05-15T22:54:46.4045896'),
(6, '2022-05-15T22:54:49.0452248'),
(7, '2022-05-17T09:10:01.0712368'),
(8, '2022-05-17T09:10:01.8199952'),
(9, '2022-05-17T09:10:02.757614'),
(10, '2022-05-17T09:10:04.7295788'),
(11, '2022-05-17T09:10:05.5001671');
