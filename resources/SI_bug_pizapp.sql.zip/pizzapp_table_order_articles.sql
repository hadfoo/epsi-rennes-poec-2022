
-- --------------------------------------------------------

--
-- Structure de la table `order_articles`
--
-- Création : mar. 17 mai 2022 à 17:36
--

DROP TABLE IF EXISTS `order_articles`;
CREATE TABLE IF NOT EXISTS `order_articles` (
  `order_id` int NOT NULL,
  `pizza_id` int NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`,`pizza_id`),
  KEY `idx_order_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;
