
-- --------------------------------------------------------

--
-- Structure de la table `pizza`
--
-- Création : sam. 14 mai 2022 à 13:32
--

DROP TABLE IF EXISTS `pizza`;
CREATE TABLE IF NOT EXISTS `pizza` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `label` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `pizza`
--

INSERT INTO `pizza` (`id`, `label`) VALUES
(1, 'Margharita'),
(2, '4Fromages'),
(3, 'Royale'),
(4, 'BBQ');
