
-- --------------------------------------------------------

--
-- Structure de la table `panier_pizza`
--
-- Création : sam. 14 mai 2022 à 18:37
-- Dernière modification : dim. 15 mai 2022 à 23:18
--

DROP TABLE IF EXISTS `panier_pizza`;
CREATE TABLE IF NOT EXISTS `panier_pizza` (
  `panier_id` int NOT NULL,
  `pizza_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `panier_pizza`
--

INSERT INTO `panier_pizza` (`panier_id`, `pizza_id`) VALUES
(4, 3),
(3, 3),
(2, 3),
(4, 1),
(4, 1),
(4, 3),
(5, 3),
(6, 1),
(10, 3),
(9, 3),
(8, 2),
(7, 1);
